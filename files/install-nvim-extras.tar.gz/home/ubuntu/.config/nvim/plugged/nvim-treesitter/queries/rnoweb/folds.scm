(rchunk) @fold
