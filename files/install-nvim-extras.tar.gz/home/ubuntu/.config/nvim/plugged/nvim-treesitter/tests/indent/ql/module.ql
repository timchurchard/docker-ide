module Test {
  predicate test() {}
}
