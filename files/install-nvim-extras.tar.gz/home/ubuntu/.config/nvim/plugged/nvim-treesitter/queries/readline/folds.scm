(conditional_construct) @fold
