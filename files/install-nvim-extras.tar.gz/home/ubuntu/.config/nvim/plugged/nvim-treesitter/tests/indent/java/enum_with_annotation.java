@Nothing
public enum Testo {
}
