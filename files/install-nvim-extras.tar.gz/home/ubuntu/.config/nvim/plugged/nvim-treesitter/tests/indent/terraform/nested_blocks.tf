test {
  nest {
    x = "bar"
  }
}
