(block) @fold
