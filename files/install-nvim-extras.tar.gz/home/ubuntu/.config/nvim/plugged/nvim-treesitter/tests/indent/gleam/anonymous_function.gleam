fn() {
  fn() {
    fn() {
      True
    }
  }
}
