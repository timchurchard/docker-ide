test {
  /*
    foo
    bar
    baz
  */
}
