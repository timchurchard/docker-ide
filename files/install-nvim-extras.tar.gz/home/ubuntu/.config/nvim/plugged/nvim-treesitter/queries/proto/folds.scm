[
  (enum)
  (message)
  (service)
] @fold
