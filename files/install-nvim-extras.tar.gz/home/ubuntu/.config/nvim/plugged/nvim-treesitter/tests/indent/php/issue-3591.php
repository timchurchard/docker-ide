<?php

function test() {
    $array = [
    ]
}
